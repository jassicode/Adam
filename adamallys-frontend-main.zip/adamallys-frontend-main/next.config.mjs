
const nextConfig = {
  /* config options here */
  images: {
    domains: ['s3-alpha-sig.figma.com', 
      "res.cloudinary.com", 
      "adamallys-space.nyc3.digitaloceanspaces.com", 
      "nyc3.digitaloceanspaces.com"],
  },
};

export default nextConfig;
