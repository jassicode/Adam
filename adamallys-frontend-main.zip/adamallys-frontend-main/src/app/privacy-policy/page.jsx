import React from 'react'
import PrivacyPolicyTemplate from "@/templates/privacy-policy/privacy-policy"

const PrivacyPolicy = async () => {
  return (
    <>
       <PrivacyPolicyTemplate/> 
    </>
  )
}

export default PrivacyPolicy