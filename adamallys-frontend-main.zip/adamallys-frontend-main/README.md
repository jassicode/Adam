https://www.figma.com/design/DY77apvNBNQlnJ84tGccti/Adamallys?node-id=0-1&t=HMfU88TIqLTe8VtA-1


V2